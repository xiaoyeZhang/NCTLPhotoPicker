//
//  TLPhotopickerDataSourcesProtocol.swift
//  TLPhotoPicker
//
//  Created by wade.hawk on 21/01/2019.
//

import UIKit
import Photos

public protocol TLPhotopickerDataSourcesProtocol {
    func headerReferenceSize() -> CGSize
    func footerReferenceSize() -> CGSize
    func registerSupplementView(collectionView: UICollectionView)
    func supplementIdentifier(kind: String) -> String
//    func configure(supplement view: UICollectionReusableView, section: (title: String, assets: [TLPHAsset]))
    // MARK: 修改第三方视图
    func configure(supplement view: UICollectionReusableView, section: (title: String, assets: [TLPHAsset]), indexPath: IndexPath, selectedAssets: [TLPHAsset])
    func changeExitAssets(supplement view: UICollectionReusableView, assets: [TLPHAsset], selectedAssets: [TLPHAsset])
}
